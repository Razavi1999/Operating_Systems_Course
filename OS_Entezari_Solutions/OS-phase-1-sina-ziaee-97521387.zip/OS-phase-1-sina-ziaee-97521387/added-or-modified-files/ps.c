//
// Created by sina ziaee on 19.06.21.
//

#include "types.h"
#include "stat.h"
#include "user.h"
#include "param.h"


// from proc_info.h proc_info structure
// per-process state // proc_info.state contains states as integers. in xv6 we have these states for processes

enum procstate {
    UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE
};

struct proc_info {
    int pid;            // Process ID
    int memsize;          // process size
    int state;            // process state
    char name[16];        // process name
};


void getProcs(int num);

int
main(int argc, char *argv[]) {

    //-------    getting a number between 1 - 64 from user *****
    printf(1, "Please enter the number of processes\n");
    char *str = gets("input: ", 5);
    int num = atoi(str);
    while (num <= 0 || num > 64){
        printf(1, "You entered %d\n", num);
        printf(1, "Please enter a number between (1, 64)\n");
        str = gets("input: ", 5);
        num = atoi(str);
    }
    printf(1, "You entered %d\n", num);
    // ***** -------------------------------------------------//

    int r = fork();

    if (r < 0) {
        //
    } // child
    else if (r == 0) {
        int r2 = fork();
        if (r2 < 0) {
        } // child
        else if (r2 == 0) {
            int r3 = fork();
            if (r3 < 0) {
            } // child
            else if (r3 == 0) {
                getProcs(num);
                exit();
            } // parent
            else {
                sbrk(1 * sizeof(char));
                while (1);
                exit();
            }
        } // parent
        else {
            sbrk(10 * sizeof(char));
            while (1);
            exit();
        }
    } // parent
    else {
        sbrk(100 * sizeof(char));
        while (1);
        exit();
    }
}

void getProcs(int num) {

    struct proc_info ptable[num];
    struct proc_info *p;
    int err;

    err = proc_dump(num * sizeof(struct proc_info), &ptable);
    if (err != 0)
        printf(1, "Error getting proc_table");

    p = &ptable[0];

    while (p != &ptable[num]) {
        // I'm printing no UNUSED processes
//        if (p->memsize > 0) {
            printf(1, "PID: %d    -    SIZE: %d    -    ", p->pid, p->memsize);
            switch (p->state) {
                case UNUSED:
                    printf(1, "STATE: %s ", "UNUSED");
                    break;
                case EMBRYO:
                    printf(1, "STATE: %s ", "EMBRYO");
                    break;
                case SLEEPING:
                    printf(1, "STATE: %s ", "SLEEPING");
                    break;
                case RUNNABLE:
                    printf(1, "STATE: %s ", "RUNNABLE");
                    break;
                case RUNNING:
                    printf(1, "STATE: %s ", "RUNNING");
                    break;
                case ZOMBIE:
                    printf(1, " %s ", "ZOMBIE");
                    break;
            }
            printf(1, "   -    NAME: %s \n", p->name);
//        }
        p++;
    }
}
