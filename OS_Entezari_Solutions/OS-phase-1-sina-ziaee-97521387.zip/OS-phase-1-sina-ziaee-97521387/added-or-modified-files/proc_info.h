//
// Created by sina ziaee on 19.06.21.
//



#include "types.h"

struct proc_info{
    uint memsize;
    int pid;
    char name[16];
    int state;
};
