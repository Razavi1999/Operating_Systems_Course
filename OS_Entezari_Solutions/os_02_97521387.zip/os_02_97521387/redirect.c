#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <wait.h>
#include <fcntl.h>

int main(int argc, char const *argv[])
{    
    // printf("This is current pid: %d\n", getpid());
    int r = fork();

    if(r < 0){
        printf("Fork failed\n");
        return 1;
    }
    else if(r == 0){
        // printf("This is the child process with pid: %d\n", getpid());
            char file[100];
    char params[100];
    char output[100];

    printf("Enter a file name:\n");
    gets(file);
    // check for existence of the file entered
    struct stat s;
    if( stat(file,&s) == 0 )
    {
        if( s.st_mode & S_IFDIR )
        {
            //it's a directory
            printf("It's a directory not a file\n");
            exit(1);
        }
        else if( s.st_mode & S_IFREG )
        {
            //it's a file
        }
        else
        {
            //something else
            printf("It's neighter a file nor directory\n");
            exit(1);
        }
    }
    else
    {
        //error
        printf("An error happened (Perhaps you should enter the abolute path of your file)\n");
        exit(1);
    }
    if( access( file, F_OK ) == 0 ) {
        // file exists
        // printf("yes\n");
    } else {
        // file doesn't exist
        printf("File does not exist\n");
        printf("returned code: 1\n");
        exit(1);
    }
    printf("Enter parameters:\n");
    gets(params);
    printf("Enter where to save your program result:\n");
    gets(output);

    char * pch;
    pch = strtok(params," ");

    
    char *my_args[20];
    int counter = 0;
    my_args[counter] = file;
    while (pch != NULL){
        counter++;
        my_args[counter] = pch;
        pch = strtok (NULL, " ");
    }
    counter++;
    my_args[counter] = NULL;

    int fd = open(output , O_CREAT | O_WRONLY | O_TRUNC , S_IRUSR | S_IWUSR);
    // Redirecting stdout to a file instead of terminal
    dup2(fd, 1);
    // Redirecting stderr to a file instead of terminal
    dup2(fd, 2);

    int returnedCode = execvp(my_args[0], my_args);
    printf("%d", returnedCode);
    printf("returned code: %d\n", returnedCode);
    }
    else{
        int rc;
        int w = wait(&rc);
	    // printf("this is a parent process of %d. pid is: %d\n", r, getpid());
        printf("pid: %d, return_code: %d\n", w, rc);
    }


    return 0;
}
